ALTER TABLE messages DROP COLUMN subject;
