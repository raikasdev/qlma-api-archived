ALTER TABLE messages ADD COLUMN subject text;
