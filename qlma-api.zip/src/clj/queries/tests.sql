-- name: delete-all-messages!
DELETE FROM messages

-- name: delete-all-users!
DELETE FROM users

-- name: delete-all-tags!
DELETE FROM tags
